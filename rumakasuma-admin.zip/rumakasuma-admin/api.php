<?php
// Admin API. Uses its own session name so it never mixes with the user site login.
session_name('RUMAKASUMA_ADMIN');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict']);
session_start();
header('Content-Type: application/json');

$DB_HOST = 'localhost';
$DB_NAME = 'rumakasuma';
$DB_USER = 'root';
$DB_PASS = '';

// Where the user site saves payment proofs (folder name must match your user site folder)
$PROOF_DIR = __DIR__ . '/../rumakasuma/uploads/proofs/';

function out($arr, $code = 200) {
    http_response_code($code);
    echo json_encode($arr);
    exit;
}

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    out(['ok' => false, 'message' => 'Database connection failed.'], 500);
}

// Creates the feedback table the first time it is needed (same definition the website uses)
function ensure_feedback_table($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS feedback (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        rating TINYINT UNSIGNED NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
}

$in = json_decode(file_get_contents('php://input'), true);
if (!is_array($in)) $in = [];
$action = $_GET['action'] ?? '';

if ($action === 'login') {
    $email = strtolower(trim($in['email'] ?? ''));
    $stmt = $pdo->prepare("SELECT id, name, password_hash FROM users WHERE email = ? AND role = 'admin'");
    $stmt->execute([$email]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$u || !password_verify($in['password'] ?? '', $u['password_hash'])) {
        out(['ok' => false, 'message' => 'Wrong email or password, or this account is not an admin.'], 401);
    }
    session_regenerate_id(true);
    $_SESSION['admin_id'] = (int)$u['id'];
    $_SESSION['admin_name'] = $u['name'];
    out(['ok' => true, 'name' => $u['name']]);
}

if ($action === 'logout') {
    $_SESSION = [];
    session_destroy();
    out(['ok' => true]);
}

// Everything below requires an admin login
if (!isset($_SESSION['admin_id'])) {
    out(['ok' => false, 'message' => 'Not logged in.'], 401);
}

switch ($action) {
    case 'me':
        out(['ok' => true, 'name' => $_SESSION['admin_name']]);

    case 'stats':
        $s = $pdo->query("SELECT COUNT(*) AS total, SUM(status='pending') AS pending,
                COALESCE(SUM(CASE WHEN status<>'cancelled' THEN total END),0) AS sales FROM orders")->fetch(PDO::FETCH_ASSOC);
        $c = $pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
        out(['ok' => true, 'orders' => (int)$s['total'], 'pending' => (int)$s['pending'],
             'sales' => (float)$s['sales'], 'customers' => (int)$c]);

    case 'orders':
        $orders = $pdo->query("SELECT o.id, o.total, o.status, o.created_at, (o.proof_image IS NOT NULL) AS has_proof, u.name, u.email
                FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
        $map = [];
        foreach ($orders as $i => $o) {
            $map[$o['id']] = $i;
            $orders[$i]['number'] = '#' . (1000 + $o['id']);
            $orders[$i]['items'] = [];
            $orders[$i]['has_proof'] = (bool)$o['has_proof'];
        }
        if ($orders) {
            $ids = implode(',', array_map('intval', array_column($orders, 'id')));
            foreach ($pdo->query("SELECT order_id, item_name, quantity FROM order_items WHERE order_id IN ($ids)") as $r) {
                $orders[$map[$r['order_id']]]['items'][] = ['name' => $r['item_name'], 'qty' => (int)$r['quantity']];
            }
        }
        out(['ok' => true, 'orders' => $orders]);

    case 'proof':
        $stmt = $pdo->prepare('SELECT proof_image FROM orders WHERE id = ?');
        $stmt->execute([(int)($_GET['id'] ?? 0)]);
        $f = $stmt->fetchColumn();
        $path = $PROOF_DIR . basename((string)$f);
        $info = $f && is_file($path) ? @getimagesize($path) : false;
        if (!$info) { http_response_code(404); exit; }
        header('Content-Type: ' . $info['mime']);
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=3600');
        readfile($path);
        exit;

    case 'update_status':
        $status = $in['status'] ?? '';
        if (!in_array($status, ['pending', 'preparing', 'completed', 'cancelled'], true)) {
            out(['ok' => false, 'message' => 'Invalid status.'], 400);
        }
        $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, (int)($in['id'] ?? 0)]);
        out(['ok' => true]);

    case 'users':
        $users = $pdo->query('SELECT id, name, email, role, created_at FROM users ORDER BY id DESC')->fetchAll(PDO::FETCH_ASSOC);
        out(['ok' => true, 'users' => $users]);

    case 'delete_order':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            out(['ok' => false, 'message' => 'POST required.'], 405);
        }
        $id = (int)($in['id'] ?? 0);
        if ($id < 1) {
            out(['ok' => false, 'message' => 'Invalid order.'], 400);
        }
        $stmt = $pdo->prepare('SELECT proof_image FROM orders WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            out(['ok' => false, 'message' => 'Order not found.'], 404);
        }
        try {
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM order_items WHERE order_id = ?')->execute([$id]);
            $pdo->prepare('DELETE FROM orders WHERE id = ?')->execute([$id]);
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            out(['ok' => false, 'message' => 'Could not delete the order.'], 500);
        }
        // Also remove the saved payment proof image from disk
        if (!empty($row['proof_image'])) {
            $file = $PROOF_DIR . basename($row['proof_image']);
            if (is_file($file)) { @unlink($file); }
        }
        out(['ok' => true]);

    case 'feedback':
        ensure_feedback_table($pdo);
        $rows = $pdo->query('SELECT id, name, rating, message, created_at FROM feedback ORDER BY id DESC LIMIT 500')
                    ->fetchAll(PDO::FETCH_ASSOC);
        $s = $pdo->query('SELECT COUNT(*) AS total, COALESCE(AVG(rating), 0) AS average FROM feedback')
                 ->fetch(PDO::FETCH_ASSOC);
        out(['ok' => true, 'total' => (int)$s['total'], 'average' => round((float)$s['average'], 2), 'feedback' => $rows]);

    case 'delete_feedback':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            out(['ok' => false, 'message' => 'POST required.'], 405);
        }
        $id = (int)($in['id'] ?? 0);
        if ($id < 1) {
            out(['ok' => false, 'message' => 'Invalid feedback.'], 400);
        }
        ensure_feedback_table($pdo);
        $del = $pdo->prepare('DELETE FROM feedback WHERE id = ?');
        $del->execute([$id]);
        if ($del->rowCount() === 0) {
            out(['ok' => false, 'message' => 'Feedback not found.'], 404);
        }
        out(['ok' => true]);

    default:
        out(['ok' => false, 'message' => 'Unknown action.'], 400);
}